"""
============================================================
INDUSTRY 5.0 INTERACTIVE DASHBOARD
Topic   : Human + AI Collaboration, Smart Manufacturing,
          Automation, Robotics, Sustainability, IoT Analytics

Author  : Hastani Pawar
Email   : pawarhastani6@gmail.com
Org     : Maulivyanshu Foundation

Framework: Streamlit + Plotly
============================================================

HOW TO RUN:

1. Install libraries:
   pip install streamlit pandas numpy plotly

2. Save file as:
   industry5_dashboard.py

3. Run:
   streamlit run industry5_dashboard.py

============================================================
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="Industry 5.0 Dashboard",
    page_icon="🏭",
    layout="wide"
)

# ============================================================
# DARK / LIGHT MODE
# ============================================================

if "dark_mode" not in st.session_state:
    st.session_state.dark_mode = True

# ============================================================
# COLORS
# ============================================================

DARK = {
    "bg": "#0d1117",
    "card": "#161b22",
    "text": "#ffffff",
    "sub": "#9ca3af",
    "accent1": "#00d4ff",
    "accent2": "#7ee787",
    "accent3": "#f78166",
    "accent4": "#d2a8ff",
    "grid": "#30363d",
    "bars": ["#00d4ff", "#7ee787", "#f78166", "#d2a8ff", "#ffa657"]
}

LIGHT = {
    "bg": "#f3f4f6",
    "card": "#ffffff",
    "text": "#111827",
    "sub": "#4b5563",
    "accent1": "#2563eb",
    "accent2": "#16a34a",
    "accent3": "#dc2626",
    "accent4": "#9333ea",
    "grid": "#d1d5db",
    "bars": ["#2563eb", "#16a34a", "#dc2626", "#9333ea", "#ea580c"]
}

C = DARK if st.session_state.dark_mode else LIGHT

# ============================================================
# CSS
# ============================================================

st.markdown(f"""
<style>

.stApp {{
    background-color: {C["bg"]};
    color: {C["text"]};
}}

[data-testid="stSidebar"] {{
    background-color: {C["card"]};
}}

h1,h2,h3,h4,h5,h6,p,div {{
    color: {C["text"]};
}}

.kpi {{
    background-color: {C["card"]};
    padding: 20px;
    border-radius: 12px;
    text-align: center;
    border: 1px solid {C["grid"]};
}}

.kpi h2 {{
    color: {C["accent1"]};
}}

.footer {{
    text-align:center;
    padding:20px;
    background:{C["card"]};
    border-radius:10px;
    margin-top:20px;
    border:1px solid {C["grid"]};
}}

</style>
""", unsafe_allow_html=True)

# ============================================================
# SAMPLE DATA
# ============================================================

np.random.seed(42)

years = [2020, 2021, 2022, 2023, 2024]
departments = ["R&D", "Production", "Quality", "Logistics"]
technologies = ["AI", "IoT", "Robotics", "Automation"]
regions = ["North", "South", "East", "West"]

data = []

for y in years:
    for d in departments:
        for t in technologies:
            for r in regions:

                production = np.random.randint(5000, 20000)

                data.append({
                    "Year": y,
                    "Department": d,
                    "Technology": t,
                    "Region": r,
                    "Production": production,
                    "AIEfficiency": np.random.randint(60, 99),
                    "RobotUtilization": np.random.randint(50, 95),
                    "EnergySavings": np.random.randint(10, 45),
                    "Productivity": np.random.randint(55, 99),
                    "IoTPoints": np.random.randint(1000, 50000)
                })

df = pd.DataFrame(data)

# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.title("⚙ Filters")

    if st.button("🌙 / ☀ Toggle Theme"):
        st.session_state.dark_mode = not st.session_state.dark_mode
        st.rerun()

    year_filter = st.multiselect(
        "Select Year",
        options=df["Year"].unique(),
        default=df["Year"].unique()
    )

    dep_filter = st.multiselect(
        "Department",
        options=df["Department"].unique(),
        default=df["Department"].unique()
    )

    tech_filter = st.multiselect(
        "Technology",
        options=df["Technology"].unique(),
        default=df["Technology"].unique()
    )

    region_filter = st.multiselect(
        "Region",
        options=df["Region"].unique(),
        default=df["Region"].unique()
    )

# ============================================================
# FILTER DATA
# ============================================================

filtered_df = df[
    (df["Year"].isin(year_filter)) &
    (df["Department"].isin(dep_filter)) &
    (df["Technology"].isin(tech_filter)) &
    (df["Region"].isin(region_filter))
]

# ============================================================
# HEADER
# ============================================================

st.title("🏭 Industry 5.0 Interactive Dashboard")
st.markdown("### Human + AI Collaboration | Robotics | IoT | Sustainability")

# ============================================================
# KPI SECTION
# ============================================================

total_production = int(filtered_df["Production"].sum())
avg_ai = round(filtered_df["AIEfficiency"].mean(), 1)
avg_robot = round(filtered_df["RobotUtilization"].mean(), 1)
avg_energy = round(filtered_df["EnergySavings"].mean(), 1)

k1, k2, k3, k4 = st.columns(4)

with k1:
    st.markdown(f"""
    <div class='kpi'>
        <h3>Total Production</h3>
        <h2>{total_production:,}</h2>
    </div>
    """, unsafe_allow_html=True)

with k2:
    st.markdown(f"""
    <div class='kpi'>
        <h3>AI Efficiency</h3>
        <h2>{avg_ai}%</h2>
    </div>
    """, unsafe_allow_html=True)

with k3:
    st.markdown(f"""
    <div class='kpi'>
        <h3>Robot Utilization</h3>
        <h2>{avg_robot}%</h2>
    </div>
    """, unsafe_allow_html=True)

with k4:
    st.markdown(f"""
    <div class='kpi'>
        <h3>Energy Savings</h3>
        <h2>{avg_energy}%</h2>
    </div>
    """, unsafe_allow_html=True)

# ============================================================
# CHART ROW 1
# ============================================================

c1, c2 = st.columns(2)

# ============================================================
# BAR CHART
# ============================================================

with c1:

    st.subheader("📊 Production by Department")

    bar_df = filtered_df.groupby("Department")["Production"].sum().reset_index()

    fig_bar = px.bar(
        bar_df,
        x="Department",
        y="Production",
        color="Department",
        color_discrete_sequence=C["bars"]
    )

    fig_bar.update_layout(
        paper_bgcolor=C["card"],
        plot_bgcolor=C["card"],
        font_color=C["text"]
    )

    st.plotly_chart(fig_bar, use_container_width=True)

# ============================================================
# LINE CHART
# ============================================================

with c2:

    st.subheader("📈 AI Efficiency Trend")

    line_df = filtered_df.groupby("Year")["AIEfficiency"].mean().reset_index()

    fig_line = go.Figure()

    fig_line.add_trace(go.Scatter(
        x=line_df["Year"],
        y=line_df["AIEfficiency"],
        mode="lines+markers",
        line=dict(color=C["accent1"], width=3),
        fill="tozeroy",

        # FIXED ERROR HERE
        fillcolor="rgba(0,212,255,0.15)"
    ))

    fig_line.update_layout(
        paper_bgcolor=C["card"],
        plot_bgcolor=C["card"],
        font_color=C["text"]
    )

    st.plotly_chart(fig_line, use_container_width=True)

# ============================================================
# CHART ROW 2
# ============================================================

c3, c4 = st.columns(2)

# ============================================================
# COLUMN CHART
# ============================================================

with c3:

    st.subheader("🏭 Energy Savings by Technology")

    col_df = filtered_df.groupby("Technology")["EnergySavings"].mean().reset_index()

    fig_col = px.bar(
        col_df,
        x="Technology",
        y="EnergySavings",
        color="Technology",
        color_discrete_sequence=C["bars"]
    )

    fig_col.update_layout(
        paper_bgcolor=C["card"],
        plot_bgcolor=C["card"],
        font_color=C["text"]
    )

    st.plotly_chart(fig_col, use_container_width=True)

# ============================================================
# PIE CHART
# ============================================================

with c4:

    st.subheader("🥧 IoT Distribution by Region")

    pie_df = filtered_df.groupby("Region")["IoTPoints"].sum().reset_index()

    fig_pie = px.pie(
        pie_df,
        names="Region",
        values="IoTPoints",
        hole=0.5,
        color_discrete_sequence=C["bars"]
    )

    fig_pie.update_layout(
        paper_bgcolor=C["card"],
        font_color=C["text"]
    )

    st.plotly_chart(fig_pie, use_container_width=True)

# ============================================================
# SCATTER CHART
# ============================================================

st.subheader("🔬 Robot Utilization vs Productivity")

fig_scatter = px.scatter(
    filtered_df,
    x="RobotUtilization",
    y="Productivity",
    color="Department",
    size="Production",
    hover_data=["Technology", "Region"],
    color_discrete_sequence=C["bars"]
)

fig_scatter.update_layout(
    paper_bgcolor=C["card"],
    plot_bgcolor=C["card"],
    font_color=C["text"]
)

st.plotly_chart(fig_scatter, use_container_width=True)

# ============================================================
# GAUGE CHART
# ============================================================

st.subheader("⚡ AI Efficiency Gauge")

fig_gauge = go.Figure(go.Indicator(
    mode="gauge+number",
    value=avg_ai,
    gauge={
        "axis": {"range": [0, 100]},
        "bar": {"color": C["accent1"]},
    }
))

fig_gauge.update_layout(
    paper_bgcolor=C["card"],
    font_color=C["text"],
    height=350
)

st.plotly_chart(fig_gauge, use_container_width=True)

# ============================================================
# DATA TABLE
# ============================================================

st.subheader("📋 Data Table")

st.dataframe(filtered_df, use_container_width=True)

# ============================================================
# FOOTER
# ============================================================

st.markdown(f"""
<div class='footer'>

<h3 style='color:{C["accent1"]};'>
Hastani Pawar
</h3>

<p>
pawarhastani6@gmail.com
</p>

<p>
Maulivyanshu Foundation
</p>

</div>
""", unsafe_allow_html=True)